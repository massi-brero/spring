# Calendar App
This app will use the journal-spring-boot-starter pom

Initialize the Project
```bash
$ spring init -name=spring-boot-calendar --package=com.apress.spring -g=com.apress.spring -a=spring-boot-calendar -x
```
