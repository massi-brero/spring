package com.apress.spring.heatlh;

public class QuotaException extends Exception {

	private static final long serialVersionUID = -1L;

	public QuotaException(String ex){
		super(ex);
	}

}
