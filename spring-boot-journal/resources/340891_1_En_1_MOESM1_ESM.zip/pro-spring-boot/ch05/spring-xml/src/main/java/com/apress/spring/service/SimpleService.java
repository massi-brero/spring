package com.apress.spring.service;

public class SimpleService {

	public String getHtmlH1From(String text){
		return "<h1>" + text + "</h1>";
	}
}