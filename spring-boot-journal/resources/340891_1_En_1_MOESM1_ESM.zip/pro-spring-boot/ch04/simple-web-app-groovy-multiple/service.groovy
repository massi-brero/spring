@Service
class MyService{	
	String getH1HeaderFrom(msg){
		"<h1>$msg</h1>"
	}	
	
	String getH3HeaderFrom(msg){
		"<h3>$msg</h3>"
	}
}