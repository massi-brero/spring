
class MyTest{    
	
	@Test
	void simple() {
		String str= "JUnit works with Spring Boot"
		assertEquals "JUnit works with Spring Boot",str 
	}
}
